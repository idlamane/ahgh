<?php

namespace Amb\AdherentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AmbAdherentBundle extends Bundle
{
}
