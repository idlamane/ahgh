<?php

namespace Amb\DebitBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AmbDebitBundle extends Bundle
{
}
